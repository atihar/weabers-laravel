   <!-- ========== Loading Page ========== -->
   <div class="preloader">
        <div class="dsnload p-absolute">
            <span class="dsnload__row">
                <span class="dsnload__img">
                    <img src="assets/img/logo.png" alt="">
                </span>
            </span>
            <span class="dsnload__row dsnload__row--sibling">
                <span class="dsnload__img">
                    <img src="assets/img/logo.png" alt="">
                </span>
            </span>
            <span class="dsnload__row dsnload__row--sibling">
                <span class="dsnload__img">
                    <img src="assets/img/logo.png" alt="">
                </span>
            </span>
            <span class="dsnload__row dsnload__row--sibling">
                <span class="dsnload__img">
                    <img src="assets/img/logo.png" alt="">
                </span>
            </span>
        </div>


        <span class="loading-text text-uppercase mt-30">BUILDING EXP...</span>

    </div>
    <!-- ========== End Loading Page ========== --><?php /**PATH C:\Users\USER\Desktop\weabers-laravel\resources\views/components/loading.blade.php ENDPATH**/ ?>